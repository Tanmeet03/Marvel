/*
 * Copyright (c) 2017. André Mion
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.example.lifcaremarvel.ui.search.view;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;

import com.example.lifcaremarvel.R;
import com.example.lifcaremarvel.api.data.CharacterVO;
import com.example.lifcaremarvel.databinding.ActivitySearchBinding;
import com.example.lifcaremarvel.databinding.ItemListSearchBinding;
import com.example.lifcaremarvel.ui.adapter.ArrayAdapter;
import com.example.lifcaremarvel.ui.character.view.CharacterActivity;
import com.example.lifcaremarvel.ui.home.view.CharacterAdapter;
import com.example.lifcaremarvel.ui.search.SearchContract;
import com.example.lifcaremarvel.ui.search.SearchPresenter;
import com.example.lifcaremarvel.ui.util.StringUtils;
import com.google.android.material.snackbar.Snackbar;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.LinearLayoutManager;

public class SearchActivity extends AppCompatActivity
        implements SearchView.OnQueryTextListener,
        SearchView.OnCloseListener, SearchContract.View,
        CharacterAdapter.OnItemClickListener<CharacterVO, CharacterAdapter.ViewHolder, ItemListSearchBinding> {

    private ActivitySearchBinding mBinding;
    private CharacterAdapter mSearchAdapter;
    private SearchPresenter mPresenter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mBinding = DataBindingUtil.setContentView(this, R.layout.activity_search);
        setSupportActionBar(mBinding.toolbar);
        //noinspection ConstantConditions
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        mBinding.search.setIconified(false);
        mBinding.search.setOnQueryTextListener(this);
        mBinding.search.setOnCloseListener(this);

        mBinding.recycler.setLayoutManager(new LinearLayoutManager(this));
        mBinding.recycler.setHasFixedSize(true);
        mBinding.recycler.setAdapter(mSearchAdapter = new CharacterAdapter(R.layout.item_list_search, this, null));

        if (savedInstanceState == null) {
            mPresenter = new SearchPresenter();
        } else {
            mPresenter = (SearchPresenter) getLastCustomNonConfigurationInstance();
        }
        mPresenter.attachView(this);
    }

    @Nullable
    @Override
    public Intent getParentActivityIntent() {
        //noinspection ConstantConditions
        return super.getParentActivityIntent().addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
    }

    @Override
    public Object onRetainCustomNonConfigurationInstance() {
        return mPresenter;
    }

    @Override
    protected void onDestroy() {
        mPresenter.detachView();
        super.onDestroy();
    }

    @Override
    public boolean onQueryTextSubmit(String query) {
        return false;
    }

    @Override
    public boolean onQueryTextChange(String newText) {
        if (!TextUtils.isEmpty(newText)) {
            mPresenter.searchCharacters(newText);
        } else {
            mPresenter.loadCharacters();
        }
        return true;
    }

    @Override
    public boolean onClose() {
        String query = mBinding.search.getQuery().toString();
        mPresenter.searchCharacters(query);
        return true;
    }

    @Override
    public void onItemClick(ArrayAdapter<CharacterVO, CharacterAdapter.ViewHolder> adapter, ItemListSearchBinding binding, int position) {
        mPresenter.characterClick(binding.image, adapter.getItem(position));
    }

    @Override
    public void showProgress() {
        mSearchAdapter.setHasMore(true);
    }

    @Override
    public void stopProgress() {
        mSearchAdapter.setHasMore(false);
    }

    @Override
    public void showResult(List<CharacterVO> entries) {
        mSearchAdapter.setItems(entries);
    }

    @Override
    public void showError(Throwable e) {
        Snackbar.make(mBinding.toolbar, StringUtils.getApiErrorMessage(this, e), Snackbar.LENGTH_LONG).show();
    }

    @Override
    public void openCharacter(@NonNull View heroView, @NonNull CharacterVO character) {
        CharacterActivity.start(this, heroView, character);
    }

}
